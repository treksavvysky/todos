# @plugins/agent-gate

Embedded API endpoint & key manager for AI agents (Custom GPTs, Claude
integrations, MCP-adjacent tooling). Each consuming app owns its agents,
keys, and spec — nothing central to run.

What it gives an app:

- **Agents** — named consumers with an endpoint allowlist.
- **API keys** — `ag_…` tokens shown once, stored SHA-256-hashed, rotatable.
- **Per-agent filtered OpenAPI spec** — only the operations the agent may
  call, unreferenced component schemas pruned, your chosen server URL/name
  injected, security scheme included. Served at an unguessable URL you paste
  straight into the Custom GPT builder.
- **Runtime enforcement** — the same permissions that filtered the spec are
  enforced on every request, so spec and reality cannot drift.
- **Admin UI** — served by the plugin at `<mount>/admin`; create agents,
  copy keys/spec URLs, assign endpoint permissions parsed from your spec.

## Usage (Express)

```ts
import { AgentGate } from "@plugins/agent-gate";
import { agentGateRouter, requireAgent } from "@plugins/agent-gate-express";

const gate = new AgentGate({
  spec: openapiDocument,                      // or async () => doc
  adminToken: process.env.AGENT_GATE_ADMIN_TOKEN!,
  storage: { file: "./agent-gate.data.json" }, // or any StorageAdapter
  server: { url: "https://api.example.com", name: "Production" },
  // auth: { scheme: "header", header: "x-api-key" }  (default: bearer)
});

app.use("/agent-gate", agentGateRouter(gate)); // admin UI + spec endpoints
app.use("/api", requireAgent(gate, { pathPrefix: "/api" })); // guard your API
```

## Usage (Next.js App Router)

```ts
// app/api/agent-gate/[[...path]]/route.ts
import { createGateHandlers } from "@plugins/agent-gate-next";
import { gate } from "@/lib/gate";
export const { GET, POST, PATCH, DELETE } = createGateHandlers(gate);
```

```ts
// inside your own route handler
const access = await requireAgent(gate, req, { pathPrefix: "/api" });
if (access instanceof Response) return access;
// access.agent, access.operation
```

## Permission strings

| Pattern | Meaning |
| --- | --- |
| `*` | every operation |
| `tag:notes` | operations tagged `notes` |
| `op:getNote` | operation with that `operationId` |
| `GET /notes/{id}` | exact method + path template |
| `GET /notes/*` | `*` globs one path segment |
| `* /notes/**` | `**` globs the rest; method `*` matches any |

## Endpoints (relative to the mount point)

| Route | Auth | Purpose |
| --- | --- | --- |
| `GET /admin` | none (UI asks for token) | admin UI |
| `GET /admin/api/state` | admin token | agents + operations |
| `POST /admin/api/agents` | admin token | create agent → key (once) |
| `PATCH /admin/api/agents/:id` | admin token | update / revoke |
| `POST /admin/api/agents/:id/rotate` | admin token | new key (once) |
| `DELETE /admin/api/agents/:id` | admin token | delete |
| `GET /spec/openapi.json?token=<specToken>` | unguessable spec token | filtered OpenAPI spec |

The spec token is **not** the API key — it is a separate random token that
only reveals the (already filtered) spec, never grants API access, and is
invalidated when the agent is deleted or revoked.

### Spec URL query parameters

| Param | Effect |
| --- | --- |
| `token` | required — the agent's spec token |
| `server` | override the injected server URL, e.g. `?server=api.plannedintent.com` (https assumed) or `?server=http://codejourney.com:4100/api` (explicit scheme kept) |
| `name` | override the server name shown in the spec |

Without `server`/`name`, the agent's configured server (or the app default)
is used. The legacy `GET /spec/<token>.json` form still works.
